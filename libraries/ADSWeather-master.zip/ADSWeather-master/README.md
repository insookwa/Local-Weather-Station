# ADSWeather
Arduino library to interface with the Argent Data Systems weather station sensor assembly. This is the weather sensor assembly sold by SparkFun at https://www.sparkfun.com/products/8942 This library provides and API so that the weather information wind direction, wind speed, maximum wind speed and rainfall ammount can be read simply from functions.
